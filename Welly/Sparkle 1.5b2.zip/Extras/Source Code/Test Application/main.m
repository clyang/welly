//
//  main.m
//  Sparkle
//
//  Created by Andy Matuschak on 3/12/06.
//  Copyright Andy Matuschak 2006. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
